﻿namespace grupa1_Rutkowski_Paweł;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");
    }
}
